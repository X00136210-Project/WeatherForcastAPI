package com.example.weatherclient;

//imports
import android.app.Activity;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;

import java.util.List;

//retrofit2 imports
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

//must extends AppCompatActivity for activity use
public class ForcastAddActivity  extends AppCompatActivity{

    //create EditText list with four spots
    private EditText[] editText = new EditText[4];

    //activity & forcast list obj.
    private Activity context;
    private List<Forcast> forcastList;

    //jsonAPI class
    private jsonPlaceHolderAPI jsonPlaceHolderApi;

    //variables - model class & edited text
    String id, name, condition, windDir, outlook;
    int maxTemp, minTemp, windSpeed;
    EditText eid, ename, econdition, emaxtemp, emintemp, ewinddir, ewindspeed, eoutlook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); //error
        setContentView(R.layout.add_activity); //error

        //post forcast button
        Button postForcastButton = (Button) findViewById(R.id.postForcastButton);

        //get the id of each EditText for user input of new info
        eid =  findViewById(R.id.newId);
        ename = findViewById(R.id.newName);
        econdition =  findViewById(R.id.newCondition);
        emaxtemp =findViewById(R.id.newMaxTemp);
        emintemp =  findViewById(R.id.newMinTemp);
        ewinddir =  findViewById(R.id.newWindDir);
        ewindspeed =  findViewById(R.id.newWindSpeed);
        eoutlook = findViewById(R.id.newOutlook);

        //build the Retrofit
        Gson gson = new GsonBuilder().serializeNulls().create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://weatherforcastapi2020.azurewebsites.net/api/Forcasts/")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        //call the json placeholder class
        jsonPlaceHolderApi = retrofit.create(jsonPlaceHolderAPI.class);

        //post forcast button - action
        postForcastButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //bring up info - parsing int vars needed
                id = eid.getText().toString();
                name = ename.getText().toString();
                condition = econdition.getText().toString();
                maxTemp = Integer.parseInt(emaxtemp.getText().toString());
                minTemp = Integer.parseInt(emintemp.getText().toString());
                windDir = ewinddir.getText().toString();
                windSpeed = Integer.parseInt(ewindspeed.getText().toString());
                outlook = eoutlook.getText().toString();

                //call the create post method
                createPost();
            }
        });
    }

    //data validation - Temp
    private boolean validateTemp() {
        String tempInput = emaxtemp.getText().toString();

        //field can't be empty
        if(tempInput.isEmpty()){
            ename.setError("Field cannot be empty");
            return false;
        }
        else{
            //no message if inputted
            ename.setError(null);
            return true;
        }
    }

    //createPost - kick off the retrofit
    private void createPost(){
        //forcast obj
        Forcast forcast = new Forcast(id, name, condition, maxTemp, minTemp, windDir, windSpeed, outlook);
        //create a post request with retrofit for the forcast json data
        Call<Forcast> call = jsonPlaceHolderApi.createPost(forcast); //error

        //call enqueue - callback on the response
        call.enqueue(new Callback<Forcast>() {
            @Override
            public void onResponse(Call<Forcast> call, Response<Forcast> response) {
                //if !response success, return
                if(!response.isSuccessful()){
                    return;
                }

                //response body for forcastResponse
                Forcast forcastResponse = response.body();
            }

            @Override
            public void onFailure(Call<Forcast> call, Throwable t) {

            }
        });
    }
}
