package com.example.weatherclient;

//model class - used to hold the json data that will be fetched
public class Forcast {

    //declare vars - all private
    private String id;
    private String name;
    private String condition;
    private int maxTemp;
    private int minTemp;
    private String windDir;
    private int windSpeed;
    private String outlook;

    //constructor - initialise vars
    public Forcast(String id, String name, String condition, int maxTemp, int minTemp, String windDir, int windSpeed, String outlook)
    {
        this.id = id;
        this.name = name;
        this.condition = condition;
        this.maxTemp = maxTemp;
        this.minTemp = minTemp;
        this.windDir = windDir;
        this.windSpeed = windSpeed;
        this.outlook = outlook;
    }

    //getters
    public String getId() {return id;}

    public String getName() {return name;}

    public String getCondition() {return condition;}

    public int getMaxTemp() {return maxTemp;}

    public int getMinTemp() {return minTemp;}

    public String getWindDir() {return windDir;}

    public int getWindSpeed() {return windSpeed;}

    public String getOutlook() {return outlook;}

    //setters
    public void setId(String id) {this.id = id;}

    public void setName(String name) {
        this.name = name;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public void setMaxTemp(int maxTemp) {
        this.maxTemp = maxTemp;
    }

    public void setMinTemp(int minTemp) {
        this.minTemp = minTemp;
    }

    public void setWindDir(String windDir) {this.windDir = windDir;}

    public void setWindSpeed(int windSpeed) {this.windSpeed = windSpeed;}

    public void setOutlook(String outlook) {this.outlook = outlook;}

    //override ToString to return values

    public String ToString(){
        return
                "id='" + id + '\'' +
                        ", name='" + name + '\'' +
                        ", condition='" + condition + '\'' +
                        ", maxTemp=" + maxTemp +
                        ", minTemp='" + minTemp + '\'' +
                        ", windDir='" + windDir + '\'' +
                        ", windSpeed='" + windSpeed + '\'' +
                        ", outlook=" + outlook +
                        '}';
    }

}
