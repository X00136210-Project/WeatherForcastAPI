package com.example.weatherclient;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import androidx.appcompat.app.AlertDialog;


import android.util.Log;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;

//import org.json.JSONArray;
//import org.json.JSONException;
///import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;



public class MainActivity extends AppCompatActivity {

    // uri of RESTful service on Azure
    private String SERVICE_URI;
    private String TAG = "helloworldvolleyclient";

    //forcast list - store forcast objects after parsing json
    private List<Forcast> forcastList;
    //ListView obj.
    ListView list;

    //EditText obj.
    EditText text;
    //by city
    EditText cityName;

    //TextView Obj.
    TextView title;

    //ForcastAdapter Obj.
    ForcastAdapter adapt;

    //Button obj(s).
    Button callAllButton, addButton, cityFilterButton;

    //use the jsonPlaceHolderAPI - retrofit2
    private jsonPlaceHolderAPI jsonPlaceHolderApi;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialise listview & forcast list, other views & buttons ect.
        //forcast list object
        forcastList = new ArrayList<>();

        //Views
        list = findViewById(R.id.list_view);
        title = findViewById(R.id.title);

        //Buttons
        callAllButton = findViewById(R.id.callAllButton);
        addButton = findViewById(R.id.addButton);
        cityFilterButton = findViewById(R.id.filterCityButton);

        //filters
        cityName = findViewById(R.id.filterCity);



        //build with retrofit
        Gson gson = new GsonBuilder().serializeNulls().create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://weatherforcastapi2020.azurewebsites.net/")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        jsonPlaceHolderApi = retrofit.create(jsonPlaceHolderAPI.class);

        //show list after called with the callService button - will lead to another activity showing specific info and delete it.
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                final int selected_item = position;
                final String index = forcastList.get(position).getId();
                Intent i = new Intent(MainActivity.this, ForcastActivity.class);
                i.putExtra("ID", forcastList.get(position).getId());
                i.putExtra("City Name", forcastList.get(position).getName());
                i.putExtra("Weather Condition", forcastList.get(position).getCondition());
                i.putExtra("Maximum Temp", forcastList.get(position).getMaxTemp());
                i.putExtra("Minimum Temp", forcastList.get(position).getMinTemp());
                i.putExtra("Wind Direction", forcastList.get(position).getWindDir());
                i.putExtra("Wind Speed", forcastList.get(position).getWindSpeed());
                i.putExtra("Outlook", forcastList.get(position).getOutlook());
                startActivity(i);
            }

        });

        //call the service on startup
        //callService();

        //get request/call all button
        callAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callService();
            }
        });

        //GET request/filter by city button
        cityName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterCity();
            }
        });

        //post request/add forcast button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addActivity();
            }
        });

        //delete based on Id
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int
                    position, long id) {

                // it will get the position of selected item from the ListView

                final int selected_item = position;
                final String index = forcastList.get(position).getId();

                new AlertDialog.Builder(MainActivity.this).
                        setIcon(android.R.drawable.ic_delete)
                        .setTitle("Are you sure...")
                        .setMessage("Do you want to delete this forcast?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                forcastList.remove(index);
                                forcastList.clear();
                                delete(index);

                            }
                        })
                        .setNegativeButton("No", null).show();

                return true;
            }
        });
    }

    //callService()
    // call GET request for RESTful service using volley and display results
    public void callService()
    {
        // get TextView for displaying result
        SERVICE_URI = "https://weatherforcastapi2020.azurewebsites.net/api/Forcasts";
        forcastList.clear();

        try
        {
            // make a string request (JSON request an alternative)
            RequestQueue queue = Volley.newRequestQueue(this);
            Log.d(TAG, "Making request");
            try
            {
                StringRequest strObjRequest = new StringRequest(Request.Method.GET, SERVICE_URI,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response)
                            {
                                // parse resulting string containing JSON to Greeting object
                                Forcast[] forcasts = new Gson().fromJson(response, Forcast[].class);
                                for (int i = 0; i < forcasts.length; i++) {
                                    forcastList.add(forcasts[i]);
                                    ForcastAdapter adapt = new ForcastAdapter(MainActivity.this, forcastList);
                                    list.setAdapter(adapt);
                                }

                                Log.d(TAG, "Displaying data" + forcasts.toString());
                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error)
                            {
                                Log.d(TAG, "Error" + error.toString());
                            }
                        });
                queue.add(strObjRequest);           // can have multiple in a queue, and can cancel
            }
            catch (Exception e1)
            {
                Log.d(TAG, e1.toString());
            }
        }
        catch (Exception e2)
        {
            Log.d(TAG, e2.toString());
        }
    }

    //filterCity()
    // call GET request for RESTful service using volley and display results
    //will display forcast based on city name only
    public void filterCity()
    {
        //make a name string to match the name inputted using the EditText obj.
        String name = cityName.getText().toString();
        // get TextView for displaying result with name
        SERVICE_URI = "https://weatherforcastapi2020.azurewebsites.net/api/Forcasts/" +name;
        forcastList.clear();

        try
        {
            // make a string request (JSON request an alternative)
            RequestQueue queue = Volley.newRequestQueue(this);
            Log.d(TAG, "Making request");
            try
            {
                StringRequest strObjRequest = new StringRequest(Request.Method.GET, SERVICE_URI,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response)
                            {
                                // parse resulting string containing JSON to Greeting object
                                //forcast single obj. - not arrayList this time
                                Forcast forcasts = new Gson().fromJson(response, Forcast.class);

                                    forcastList.add(forcasts);
                                    ForcastAdapter adapt = new ForcastAdapter(MainActivity.this, forcastList);
                                    list.setAdapter(adapt);

                                Log.d(TAG, "Displaying data" + forcasts.toString());
                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error)
                            {
                                Log.d(TAG, "Error" + error.toString());
                            }
                        });
                queue.add(strObjRequest);           // can have multiple in a queue, and can cancel
            }
            catch (Exception e1)
            {
                Log.d(TAG, e1.toString());
            }
        }
        catch (Exception e2)
        {
            Log.d(TAG, e2.toString());
        }
    }


    //request to post/add forcast
    private void addActivity(){

        Intent intent = new Intent(this, ForcastAddActivity.class);
        startActivity(intent);
    }

    //delete a weather forcast
    //delete with DELETE Request
    public void delete(String id) {

        retrofit2.Call<Void> call = jsonPlaceHolderApi.delete(id);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, retrofit2.Response<Void> response) {

            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {

            }


        });
    }
}
