package com.example.weatherclient;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ForcastAdapter extends ArrayAdapter<Forcast> {

    //context object
    private Activity context;
    //create forcast list that will be displayed
    private List<Forcast> forcastList;

    //get the forcastList and context
    //while creating the object of the adapter class and we need to give forcastlist and context
    public ForcastAdapter(Activity context, List<Forcast> forcastList){
        super(context, R.layout.content_forcast, forcastList);
        this.context = context;
        this.forcastList = forcastList;
    }

    //this method will return the list items
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        //getting the layoutInflater
        LayoutInflater inflater = context.getLayoutInflater();

        //create a view with our xmp layout
        View listViewItem = inflater.inflate(R.layout.content_forcast,null,true);

        //TextViews for the model data to be project into ListView
        TextView id = (TextView) listViewItem.findViewById(R.id.id);
        TextView name = (TextView) listViewItem.findViewById(R.id.name);
        TextView condition = (TextView) listViewItem.findViewById(R.id.condition);
        TextView maxTemp = (TextView) listViewItem.findViewById(R.id.maxTemp);
        TextView minTemp = (TextView) listViewItem.findViewById(R.id.minTemp);
        TextView windDir = (TextView) listViewItem.findViewById(R.id.windDir);
        TextView windSpeed =  (TextView) listViewItem.findViewById(R.id.windSpeed);
        TextView outlook = (TextView) listViewItem.findViewById(R.id.outlook);

        //getting the forcasts for the specified positions
        Forcast forcast = forcastList.get(position);

        //set forcast values to TextViews
        id.setText("Forecast ID : " +forcast.getId());
        name.setText("City Name : " +forcast.getName());
        condition.setText("Weather Condition : " +forcast.getCondition());
        maxTemp.setText("Max Temp (Celsius): " +forcast.getMaxTemp());
        minTemp.setText("Min Temp (Celsius): " +forcast.getMinTemp());
        windDir.setText("Wind Direction : " +forcast.getWindDir());
        windSpeed.setText("Wind Speed (km/h): " +forcast.getWindSpeed());
        outlook.setText("Outlook : " +forcast.getOutlook());

        //return the listView with the TextView inserted with forcast data
        return listViewItem;
    }
}
