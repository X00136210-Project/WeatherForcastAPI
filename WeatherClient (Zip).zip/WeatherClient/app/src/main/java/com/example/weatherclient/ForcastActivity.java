package com.example.weatherclient;


///imports
import android.app.Activity;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.widget.TextView;

import java.util.List;

//retrofit2 imports
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

//must extends AppCompatActivity for activity use
//overview of a forcast with option to delete
public class ForcastActivity  extends AppCompatActivity{

    //jsonAPI class
    private jsonPlaceHolderAPI jsonPlaceHolderApi;

    //variables - model class & edited text
    String id, name, condition, windDir, outlook;
    int maxTemp, minTemp, windSpeed;

    //display forcast info in question
    TextView tid, tname, tcondition, tmaxtemp, tmintemp, twinddir, twindspeed, toutlook;

    //Button for update
    Button updateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); //error
        setContentView(R.layout.forcast_activity); //make sure xml exists!

        //update forcast button
        updateButton = (Button) findViewById(R.id.updateButton); //update button in xml!

        //get intent of each data (ie: the data to be displayed)
        id = getIntent().getExtras().getString("City ID");
        name = getIntent().getExtras().getString("City Name");
        condition = getIntent().getExtras().getString("Weather Condition");
        maxTemp = getIntent().getExtras().getInt("Maximum Temp (Celsius)");
        maxTemp = getIntent().getExtras().getInt("Minimum Temp (Celsius)");
        windDir = getIntent().getExtras().getString("Wind Direction");
        windSpeed = getIntent().getExtras().getInt("Wind Speed (km/h)");
        outlook =  getIntent().getExtras().getString("Outlook");

        //get the id of specific TextView for forcast info
        tid =  findViewById(R.id.aId); //xml reference for TextView!
        tname = findViewById(R.id.aName);
        tcondition =  findViewById(R.id.aCondition);
        tmaxtemp =findViewById(R.id.aMaxTemp);
        tmintemp =  findViewById(R.id.aMinTemp);
        twinddir =  findViewById(R.id.aWindDir);
        twindspeed =  findViewById(R.id.aWindSpeed);
        toutlook = findViewById(R.id.aOutlook);

        //setting values to each view
        //parse to string then textView for ints
        //tid.setText(id); - not required
        tname.setText(name);
        tcondition.setText(condition);
        String numberStrOne = Integer.toString(maxTemp);
        tmaxtemp.setText("Max Celsius : " +numberStrOne);
        String numberStrTwo = Integer.toString(minTemp);
        tmintemp.setText("Min Celsius : " +numberStrTwo);
        twinddir.setText(windDir);
        String numberStrThree = Integer.toString(windSpeed);
        twindspeed.setText("Wind Speed : " +numberStrThree);
        toutlook.setText(outlook);


        //build the Retrofit
        Gson gson = new GsonBuilder().serializeNulls().create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://weatherforcastapi2020.azurewebsites.net/api/Forcasts/")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        //call the json placeholder class
        jsonPlaceHolderApi = retrofit.create(jsonPlaceHolderAPI.class);

        //delete forcast button - action
        updateButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //call the delete method
                deleteForcast();
            }
        });
    }


    //delete forcast - create a putPost request as well if needed
    private void deleteForcast(){
        //forcast obj
        Forcast forcast = new Forcast(id, name, condition, maxTemp, minTemp, windDir, windSpeed, outlook);
        //create a PUT request with retrofit for the forcast json data
        retrofit2.Call<Forcast> call = jsonPlaceHolderApi.putPost(id, forcast);

        //call enqueue - callback on the response
        call.enqueue(new Callback<Forcast>() {
            @Override
            public void onResponse(Call<Forcast> call, Response<Forcast> response) {
                //if !response success, return
                if(!response.isSuccessful()){
                    return;
                }

                //response body for forcastResponse
                Forcast forcastResponse = response.body();
            }

            @Override
            public void onFailure(Call<Forcast> call, Throwable t) {

            }
        });
    }
}

