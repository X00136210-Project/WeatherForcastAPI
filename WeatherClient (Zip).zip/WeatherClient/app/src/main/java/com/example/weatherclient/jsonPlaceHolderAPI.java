package com.example.weatherclient;

//imports needed for Retrofit with he RESTful service
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.PATCH;

import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.DELETE;
import retrofit2.http.Path;

//must be interface!
public interface jsonPlaceHolderAPI {

    @PUT("/api/Forcasts/{id}")
    Call<Forcast> putPost(@Path("id") String id, @Body Forcast forcast);

    @POST("/api/Forcasts/")
    Call<Forcast>createPost(@Body Forcast forcast);

    @DELETE
    Call<Void> delete(@Path("id") String id);

}
